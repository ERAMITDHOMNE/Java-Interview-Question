package strings;

public class ToStringMethod {

	public static void main(String[] args) {
		String obj = new String("Hello World");
		System.out.println("String Value: " + obj);

	}

}
