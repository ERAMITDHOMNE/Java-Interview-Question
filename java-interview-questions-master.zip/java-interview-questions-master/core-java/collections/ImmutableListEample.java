package collections;

public class ImmutableListEample {

	public static void main(String[] args) {
		

	}

}
