package basics;

public class StringBuilderAppend01 {

	public static void main(String[] args) {
		StringBuilder sb = new StringBuilder("StringBuilder Append boolean value:- ");

		// Appending the boolean value
		sb.append(36.47);
		System.out.println("Output: " + sb);
	}
}
